import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Scanner;

public class Main {
    private static Hashtable<String, Cliente> registros = new Hashtable<>();

    public static void main(String[] args) {
        readFile();
        Scanner scanner = new Scanner(System.in);
        int opcion = 0;
        String claveSucursal, nombreTitular, clabe;
        double saldo;

        while (opcion != 5) {
            System.out.println("Menú.");
            System.out.println("1) Alta de cliente");
            System.out.println("2) Eliminar un cliente");
            System.out.println("3) Buscar clientes por sucursal");
            System.out.println("4) Imprimir en archivo de texto");
            System.out.println("5) Salir");
            System.out.print("Ingrese una opción: ");

            try {
                opcion = scanner.nextInt();
                scanner.nextLine();

                switch (opcion) {
                    case 1:
                        System.out.print("Ingrese la clave de la sucursal: ");
                        claveSucursal = scanner.nextLine();
                        System.out.print("Ingrese el nombre del titular: ");
                        nombreTitular = scanner.nextLine();
                        System.out.print("Ingrese la CLABE: ");
                        clabe = scanner.nextLine();
                        System.out.print("Ingrese el saldo: ");
                        saldo = scanner.nextDouble();
                        scanner.nextLine();

                        if (add(clabe, new Cliente(claveSucursal, nombreTitular, clabe, saldo))) {
                            System.out.println("Cliente agregado exitosamente.");
                        } else {
                            System.out.println("Error al agregar el cliente.");
                        }
                        break;

                    case 2:
                        System.out.print("Ingrese la CLABE del cliente a eliminar: ");
                        clabe = scanner.nextLine();

                        if (delete(clabe)) {
                            System.out.println("Cliente eliminado exitosamente.");
                        } else {
                            System.out.println("Error al eliminar el cliente.");
                        }
                        break;

                    case 3:
                        System.out.print("Ingrese la clave de la sucursal para buscar clientes: ");
                        claveSucursal = scanner.nextLine();

                        String resultado = searchBySucursal(claveSucursal);
                        System.out.println(resultado);
                        break;

                    case 4:
                        if (print()) {
                            System.out.println("Se ha imprimido correctamente.");
                        } else {
                            System.out.println("Ha ocurrido un error.");
                        }
                        break;

                    case 5:
                        System.out.println("Saliendo del programa.");
                        break;

                    default:
                        System.out.println("Seleccione una opción válida.");
                }
            } catch (Exception e) {
                System.out.println("Entrada inválida. Por favor, intente de nuevo.");
                scanner.nextLine();
            }
        }

        scanner.close();
    }

    public static boolean add(String clabe, Cliente cliente) {
        if (clabe != null && cliente != null) {
            registros.put(clabe, cliente);
            return true;
        }
        return false;
    }

    public static boolean delete(String clabe) {
        if (registros.remove(clabe) != null) {
            return true;
        }
        return false;
    }

    public static String searchBySucursal(String claveSucursal) {
        StringBuilder resultado = new StringBuilder();
        for (Cliente cliente : registros.values()) {
            if (cliente.getClaveSucursal().equals(claveSucursal)) {
                resultado.append(cliente.toString()).append("\n");
            }
        }
        if (resultado.length() == 0) {
            return "No se encontraron clientes en la sucursal.";
        }
        return resultado.toString();
    }

    public static boolean print() {
        try (FileWriter writer = new FileWriter("clientes.txt")) {
            Enumeration<Cliente> clientes = registros.elements();
            while (clientes.hasMoreElements()) {
                Cliente cliente = clientes.nextElement();
                writer.write(cliente.getClaveSucursal() + " " + cliente.getNombreTitular() + " " + cliente.getClabe() + " " + cliente.getSaldo() + "\n");
            }
            return true;
        } catch (IOException e) {
            System.out.println("Error al escribir en el archivo");
            return false;
        }
    }

    public static void readFile() {
        try (FileReader archivo = new FileReader("clientes.txt");
             BufferedReader contenedor = new BufferedReader(archivo)) {
            String información;
            while ((información = contenedor.readLine()) != null) {
                String[] partes = información.split(" ", 4);
                String claveSucursal = partes[0];
                String nombreTitular = partes[1];
                String clabe = partes[2];
                double saldo = Double.parseDouble(partes[3]);
                add(clabe, new Cliente(claveSucursal, nombreTitular, clabe, saldo));
            }
        } catch (IOException e) {
            System.out.println("Error al leer el archivo");
        }
    }
}
