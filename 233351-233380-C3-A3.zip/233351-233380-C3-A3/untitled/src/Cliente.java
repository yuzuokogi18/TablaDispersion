public class Cliente {
    private String claveSucursal;
    private String nombreTitular;
    private String clabe;
    private double saldo;

    public Cliente(String claveSucursal, String nombreTitular, String clabe, double saldo) {
        this.claveSucursal = claveSucursal;
        this.nombreTitular = nombreTitular;
        this.clabe = clabe;
        this.saldo = saldo;
    }

    public String getClaveSucursal() {
        return claveSucursal;
    }

    public void setClaveSucursal(String claveSucursal) {
        this.claveSucursal = claveSucursal;
    }

    public String getNombreTitular() {
        return nombreTitular;
    }

    public void setNombreTitular(String nombreTitular) {
        this.nombreTitular = nombreTitular;
    }

    public String getClabe() {
        return clabe;
    }

    public void setClabe(String clabe) {
        this.clabe = clabe;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    @Override
    public String toString() {
        return "Sucursal: " + claveSucursal + ", Titular: " + nombreTitular + ", CLABE: " + clabe + ", Saldo: " + saldo;
    }
}
